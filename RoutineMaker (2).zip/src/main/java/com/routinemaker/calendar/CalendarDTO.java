package com.routinemaker.calendar;

import lombok.Data;

@Data
public class CalendarDTO {

	private String memberseq;
	private String name;
	private String id;

}
