package com.routinemaker.myroutine;

import org.springframework.stereotype.Repository;

@Repository
public class MyroutineDAO {

	
	
}
