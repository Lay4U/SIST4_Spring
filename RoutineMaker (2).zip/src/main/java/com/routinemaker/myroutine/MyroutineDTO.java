package com.routinemaker.myroutine;

public class MyroutineDTO {

}
