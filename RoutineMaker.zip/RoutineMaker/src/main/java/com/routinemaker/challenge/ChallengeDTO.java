package com.routinemaker.challenge;

public class ChallengeDTO {

}
