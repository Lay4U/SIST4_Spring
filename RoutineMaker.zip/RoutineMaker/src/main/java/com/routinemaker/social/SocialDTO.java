package com.routinemaker.social;

public class SocialDTO {

}
