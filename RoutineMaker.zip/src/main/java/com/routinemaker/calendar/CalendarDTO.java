package com.routinemaker.calendar;

public class CalendarDTO {

}
