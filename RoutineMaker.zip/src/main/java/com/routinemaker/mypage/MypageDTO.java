package com.routinemaker.mypage;

public class MypageDTO {

}
