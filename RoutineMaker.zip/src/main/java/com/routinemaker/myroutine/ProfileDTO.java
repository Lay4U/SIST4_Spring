package com.routinemaker.myroutine;

import lombok.Data;

@Data
public class ProfileDTO {
	
	private String memberseq;
	private String name;
	private String id;
	private String pw;
	private String birth;
	private String selfIntro;
	private String regdate;

}
