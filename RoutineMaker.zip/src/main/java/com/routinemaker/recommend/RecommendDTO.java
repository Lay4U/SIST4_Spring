package com.routinemaker.recommend;

public class RecommendDTO {

}
